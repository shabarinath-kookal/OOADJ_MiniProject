package com.example.reaper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "";
    Button log_in;
    Button sign_in;
    EditText Text;
    EditText pass;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log_in = (Button) findViewById(R.id.log_in);
        sign_in = (Button) findViewById(R.id.sign_in);
        Text=(EditText)findViewById(R.id.TextField);
        pass=(EditText)findViewById(R.id.Textpassword);
        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Signin_Page.class);
                startActivity(intent);
            }
        });
        log_in.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                String username=Text.getText().toString().trim();
                String password=pass.getText().toString().trim();
                //Log.d(TAG,":" +username +"username");
                firebaseDatabase=FirebaseDatabase.getInstance();
                //Toast.makeText(getApplicationContext(),username,Toast.LENGTH_SHORT).show();
                if(username.length() > 0 && password.length() > 0)
                {
                reference = firebaseDatabase.getReference("User_Details").child(username);
                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String _username = null,_password=null;
                        String name = null,phone_number = null,address = null,state=null;
                        try {
                             _username = snapshot.child("username").getValue().toString();
                             _password = snapshot.child("password").getValue().toString();
                             name = snapshot.child("name").getValue().toString();
                             phone_number = snapshot.child("phone").getValue().toString();
                             address = snapshot.child("address").getValue().toString();
                             state = snapshot.child("state").getValue().toString();
                            if (username.equals(_username) && password.equals(_password) && _username!=null && _password!=null) //check with database
                            {
                                log_in_page(name,phone_number,address,state,username);
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (Exception e)
                        {
                            Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        }

                        //Toast.makeText(getApplicationContext(),"Username :"+_username+", Password :"+_password,Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(getApplicationContext(), "Please Try Again", Toast.LENGTH_SHORT).show();
                    }
                });
            }
                else
                {
                    Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void log_in_page(String name, String phone,String address,String state,String username) {

        Intent intent = new Intent(getApplicationContext(),Profile_Page.class); //login page
        intent.putExtra("Name",name);
        intent.putExtra("Phone",phone);
        intent.putExtra("Address",address);
        intent.putExtra("State",state);
        intent.putExtra("Username",username);
        startActivity(intent);
    }

}