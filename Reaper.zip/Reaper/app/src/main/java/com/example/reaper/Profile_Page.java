package com.example.reaper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class Profile_Page extends AppCompatActivity {

    private ImageView profile_pic;
    public Uri imageUri;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    TextView name_t,phone_t,place_t,click_here;
    String name,phone,address,state,username;
    Button chat_;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        name=getIntent().getStringExtra("Name");
        phone=getIntent().getStringExtra("Phone");
        address=getIntent().getStringExtra("Address");
        state=getIntent().getStringExtra("State");
        username=getIntent().getStringExtra("Username");
        setContentView(R.layout.activity_profile__page);
        profile_pic=findViewById(R.id.profile_picture);
        name_t=(TextView) findViewById(R.id.textView12);
        place_t=(TextView) findViewById(R.id.place_t);
        phone_t=(TextView) findViewById(R.id.number_t);
        click_here=(TextView)findViewById(R.id._click_here);
        place_t.setText(address);
        name_t.setText(name);
        phone_t.setText(phone);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        storageReference.child(state+"/"+username+"/Profile_Picture.jpg").getBytes(1024*1024*15)
                .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                    @Override
                    public void onSuccess(byte[] bytes) {
                        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        click_here.setVisibility(View.INVISIBLE);
                        profile_pic.setImageBitmap(bmp);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        //Toast.makeText(getApplicationContext(), "No Image", Toast.LENGTH_LONG).show();

                    }
                });
        chat_ = (Button) findViewById(R.id.chat);
        chat_.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openActivity3();
            }
        });
        profile_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choosePicture();
            }
        });
    }




    private void choosePicture()
    {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
            imageUri = data.getData();
            profile_pic.setImageURI(imageUri);
            uploadPicture();
        }
    }

    private void uploadPicture() {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();
        final String randomkey = UUID.randomUUID().toString();
        StorageReference ImageRef = storageReference.child(state+"/"+username+"/Profile_Picture.jpg");

        ImageRef.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        pd.dismiss();
                        Snackbar.make(findViewById(android.R.id.content),"ImageUploded",Snackbar.LENGTH_LONG).show();
                        click_here.setVisibility(View.INVISIBLE);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(),"Falied To Upload",Toast.LENGTH_LONG).show();

                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        double progressPercent =(100.00 * snapshot.getBytesTransferred()/snapshot.getTotalByteCount());
                        pd.setMessage("Percent: "+(int)progressPercent+"%");

                    }
                });


    }

    public void openActivity3() {

        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
        intent.putExtra("State",state);
        intent.putExtra("Username",username);
        startActivity(intent);
    }
}