package com.example.reaper;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.regex.Pattern;

import static java.sql.Types.NULL;


public class Signin_Page extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] states = {"Andhra Pradesh", "Arunachal Pradesh ", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli", "Daman and Diu", "Lakshadweep", "National Capital Territory of Delhi", "Puducherry"};
    Button save,upload;
    EditText name, pass, pass1, address, aadhaar, phone, username;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;
    public Uri imageUri;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    TextView some_text;
    int temp=0;
    String user_name, user_phone, user_address, state, user_uname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin__page);
        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, states);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);
        save = (Button) findViewById(R.id.button);
        upload = (Button) findViewById(R.id.upload);
        name = (EditText) findViewById(R.id.name);
        phone = (EditText) findViewById(R.id.phone);
        pass = (EditText) findViewById(R.id.password);
        pass1 = (EditText) findViewById(R.id.password1);
        address = (EditText) findViewById(R.id.address);
        aadhaar = (EditText) findViewById(R.id.aadhaar);
        some_text=(TextView) findViewById(R.id.some_text);
        username = (EditText) findViewById(R.id.username);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_name = name.getText().toString().trim();
                user_phone = phone.getText().toString().trim();
                user_address = address.getText().toString().trim();
                String user_aadhaar = aadhaar.getText().toString().trim();
                String user_password = pass.getText().toString();
                String user_password1 = pass1.getText().toString();
                state = spin.getSelectedItem().toString();
                user_uname = username.getText().toString().trim();
                if (check_field(user_name, "Name") == 1 && check_field(user_phone, "Phone") == 1 && check_field(user_address, "Address") == 1 && check_field(user_aadhaar, "Aadhaar") == 1) {
                    if (user_password.equals(user_password1) && check_field(user_password, "Password") == 1) {
                        //Toast.makeText(getApplicationContext(),"Works",Toast.LENGTH_SHORT).show();
                        firebaseDatabase = FirebaseDatabase.getInstance();
                        reference = firebaseDatabase.getReference("User_Details");
                        set_values helperClass = new set_values(user_name, user_phone, user_address, user_aadhaar, user_password, state, user_uname);
                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                String temp_get;
                                try {
                                    temp_get = snapshot.child(user_uname).child("username").getValue().toString();
                                    if (temp_get.equals(user_uname)) {
                                        Toast_message("User Already Exists");
                                    }
                                }
                                catch (NullPointerException e) {
                                        reference.child(user_uname).setValue(helperClass);
                                        Toast_message("User Added Successfully");
                                        save.setVisibility(View.INVISIBLE);
                                        some_text.setVisibility(View.VISIBLE);
                                        upload.setVisibility(View.VISIBLE);
                                        upload.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            choose_doc();
                                        }
                                    });
                                        return;
                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast_message("Please Try After Some Time");
                            }
                        });
                    } else if (!user_password.equals(user_password1)) {
                        Toast_message("Passwords Fields Should have the same Password");
                    }
                }
            }
        });

    }
    private void choose_doc() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,1);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
            imageUri = data.getData();
            uploadPicture();
        }
    }

    private void uploadPicture() {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();
        final String randomkey = UUID.randomUUID().toString();
        StorageReference ImageRef = storageReference.child(state+"/"+user_uname+"/Document.jpg");

        ImageRef.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        pd.dismiss();
                        Snackbar.make(findViewById(android.R.id.content),"Document Uploded",Snackbar.LENGTH_LONG).show();
                        new CountDownTimer(1000, 500) {

                            public void onTick(long millisUntilFinished) {
                            }

                            public void onFinish() {
                                Profile_page(user_name, user_phone, user_address, state, user_uname);
                            }
                        }.start();


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(),"Falied To Upload Document",Toast.LENGTH_LONG).show();
                        some_text.setVisibility(View.INVISIBLE);
                        upload.setVisibility(View.INVISIBLE);
                        save.setVisibility(View.VISIBLE);

                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        double progressPercent =(100.00 * snapshot.getBytesTransferred()/snapshot.getTotalByteCount());
                        pd.setMessage("Percent: "+(int)progressPercent+"%");

                    }
                });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //Toast.makeText(getApplicationContext(),states[position],Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void Toast_message(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    static class VerhoeffAlgorithm {
        static int[][] d = new int[][]
                {
                        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
                        {1, 2, 3, 4, 0, 6, 7, 8, 9, 5},
                        {2, 3, 4, 0, 1, 7, 8, 9, 5, 6},
                        {3, 4, 0, 1, 2, 8, 9, 5, 6, 7},
                        {4, 0, 1, 2, 3, 9, 5, 6, 7, 8},
                        {5, 9, 8, 7, 6, 0, 4, 3, 2, 1},
                        {6, 5, 9, 8, 7, 1, 0, 4, 3, 2},
                        {7, 6, 5, 9, 8, 2, 1, 0, 4, 3},
                        {8, 7, 6, 5, 9, 3, 2, 1, 0, 4},
                        {9, 8, 7, 6, 5, 4, 3, 2, 1, 0}
                };
        static int[][] p = new int[][]
                {
                        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
                        {1, 5, 7, 6, 2, 8, 3, 0, 9, 4},
                        {5, 8, 0, 3, 7, 9, 6, 1, 4, 2},
                        {8, 9, 1, 6, 0, 4, 3, 5, 2, 7},
                        {9, 4, 5, 3, 1, 2, 6, 8, 7, 0},
                        {4, 2, 8, 6, 5, 7, 3, 9, 0, 1},
                        {2, 7, 9, 3, 8, 0, 6, 4, 1, 5},
                        {7, 0, 4, 6, 9, 1, 3, 2, 5, 8}
                };
        static int[] inv = {0, 4, 3, 2, 1, 5, 6, 7, 8, 9};

        public static boolean validateVerhoeff(String num) {
            int c = 0;
            int[] myArray = StringToReversedIntArray(num);
            for (int i = 0; i < myArray.length; i++) {
                c = d[c][p[(i % 8)][myArray[i]]];
            }

            return (c == 0);
        }

        private static int[] StringToReversedIntArray(String num) {
            int[] myArray = new int[num.length()];
            for (int i = 0; i < num.length(); i++) {
                myArray[i] = Integer.parseInt(num.substring(i, i + 1));
            }
            myArray = Reverse(myArray);
            return myArray;
        }

        private static int[] Reverse(int[] myArray) {
            int[] reversed = new int[myArray.length];
            for (int i = 0; i < myArray.length; i++) {
                reversed[i] = myArray[myArray.length - (i + 1)];
            }
            return reversed;
        }
    }

    public static boolean validateAadharNumber(String aadharNumber) {
        Pattern aadharPattern = Pattern.compile("\\d{12}");
        boolean isValidAadhar = aadharPattern.matcher(aadharNumber).matches();
        if (isValidAadhar) {
            isValidAadhar = VerhoeffAlgorithm.validateVerhoeff(aadharNumber);
        }
        return isValidAadhar;
    }

    public int check_field(String field, String Toast_m) {
        if (!field.equals("") && !field.equals(" ")) {
            if (Toast_m.equals("Aadhaar")) {
                if (validateAadharNumber(field)) {
                    //Toast_message("Valid Aadhaar");
                    return 1;
                } else {
                    Toast_message("Invalid Aadhaar");
                    return 0;
                }
            } else if (Toast_m.equals("Phone")) {
                if (field.length() == 10) {
                    return 1;
                } else {
                    Toast_message("Invalid Mobile Number");
                    return 0;
                }
            }
            return 1;
        } else {
            Toast_message(Toast_m + " Field cannot be empty");
            return 0;
        }
    }

    public void delay(int time)
    {
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {

            }
        }, time*1000);
    }
    public void Profile_page(String name,String phone,String address,String state,String username) {

        Intent intent = new Intent(getApplicationContext(),Profile_Page.class); //profile page
        intent.putExtra("Name",name);
        intent.putExtra("Phone",phone);
        intent.putExtra("Address",address);
        intent.putExtra("State",state);
        intent.putExtra("Username",username);
        startActivity(intent);
    }

}