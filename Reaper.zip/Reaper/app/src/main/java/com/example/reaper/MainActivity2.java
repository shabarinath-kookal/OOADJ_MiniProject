package com.example.reaper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity2 extends AppCompatActivity {
    TextView chat_message;
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference reference;
    String state,username;
    Button send;
    EditText myedit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        send =(Button)findViewById(R.id.btnsend);
        myedit=(EditText)findViewById(R.id.edit_Text);
        state=getIntent().getStringExtra("State");
        username=getIntent().getStringExtra("Username");
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMessage(view);
            }
        });

        /*
        listView=(ListView)findViewById(R.id.list);
        ArrayList<String> arrayList=new ArrayList<>();
        chat_message=(EditText) findViewById(R.id.chat_message);
        String message=chat_message.getText().toString();
        ArrayAdapter arrayAdapter =new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);
        chat_message.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                   arrayList.add(chat_message.getText().toString());
                    Toast.makeText(getApplicationContext(), chat_message.getText(), Toast.LENGTH_SHORT).show();
                    listView.setAdapter(arrayAdapter);
                    return true;
                }
                return false;
            }

            init();


        });*/

        reference= FirebaseDatabase.getInstance().getReference("messages");
        TextView mytext=(TextView) findViewById(R.id.text_send);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               Object temp;
               try{
                   mytext.setText("");
                   temp=snapshot.child(state).getValue();
                   String temp_child[]=temp.toString().split(",");
                   for(int i=0;i<temp_child.length;i++)
                   {
                       mytext.append(temp_child[i].substring(temp_child[i].indexOf("=")+1).replace("{","").replace("}","")+"\n");
                   }
               }
               catch (NullPointerException e)
               {
                   //do nothing
               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                //mytext.setText("cancelled");

            }
        });
    }

    public void sendMessage(View view){


        reference.child(state).push().setValue(username+":"+myedit.getText().toString());
        myedit.setText("");


    }



    }




